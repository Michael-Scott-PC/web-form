import React from 'react';
import './App.css';
import CustomForm from './components/CustomForm';

function App() {
  return (
    <div className="App">
      <CustomForm />
    </div>
  );
}

export default App;
